#include "utils.h"
#include "kbcClient.h"


int 
main() {
    log("2 client ");
    client();
}
